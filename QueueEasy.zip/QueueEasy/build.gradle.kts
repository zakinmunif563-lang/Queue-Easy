plugins {
    id("com.android.application") version "9.1.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.0" apply false
    // Tambahkan baris ini jika belum ada
    id("com.google.gms.google-services") version "4.4.1" apply false
}