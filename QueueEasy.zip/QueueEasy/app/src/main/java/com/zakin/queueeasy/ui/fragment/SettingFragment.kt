package com.zakin.queueeasy.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.zakin.queueeasy.databinding.FragmentSettingBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingFragment : Fragment() {

    private var _binding: FragmentSettingBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Tampilkan Tanggal Real-time Otomatis sesuai setelan wilayah Indonesia
        try {
            val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID"))
            val currentDate = dateFormat.format(Date())
            binding.tvCurrentDate.text = currentDate
        } catch (e: Exception) {
            binding.tvCurrentDate.text = "Gagal memuat tanggal"
        }

        // Logika interaksi switch notifikasi
        binding.switchVoiceNotif.setOnCheckedChangeListener { _, isChecked ->
            val status = if (isChecked) "Aktif" else "Nonaktif"
            Toast.makeText(context, "Notifikasi Suara $status", Toast.LENGTH_SHORT).show()
        }

        binding.switchVibrateNotif.setOnCheckedChangeListener { _, isChecked ->
            val status = if (isChecked) "Aktif" else "Nonaktif"
            Toast.makeText(context, "Pengingat Getar $status", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}