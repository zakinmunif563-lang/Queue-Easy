package com.zakin.queueeasy.model

data class User(
    val userId: String = "",
    val nama: String = "",
    val noHp: String = "",
    val jenisDisabilitas: String = "", // TUNA_NETRA, TUNA_RUNGU, TUNA_DAKSA, LANSIA, UMUM
    val preferensi: Preferensi = Preferensi()
)

data class Preferensi(
    val suara: Boolean = true,
    val getar: Boolean = true,
    val flash: Boolean = true
)