package com.zakin.queueeasy.utils

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class TtsManager(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var isReady = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            // Perbaikan struktur pemanggilan objek Locale modern untuk Bahasa Indonesia
            val localeIndo = Locale.Builder().setLanguage("id").setRegion("ID").build()
            val result = tts?.setLanguage(localeIndo)
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isReady = true
            }
        }
    }

    fun speak(text: String) {
        if (isReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "QueueEasyTTS")
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}