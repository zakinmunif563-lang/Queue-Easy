package com.zakin.queueeasy.ui.fragment

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.zakin.queueeasy.databinding.FragmentHomeBinding
import com.zakin.queueeasy.utils.TtsManager
import java.util.Locale

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var ttsManager: TtsManager
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var speechIntent: Intent

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        ttsManager = TtsManager(requireContext())

        // 1. Cek & Minta Izin Mikrofon saat halaman dibuka
        checkMicrophonePermission()

        // 2. Setup Speech Recognition (STT)
        setupSpeechToText()

        // 3. Tombol Ambil Antrian Manual
        binding.btnAmbilAntrian.setOnClickListener {
            triggerAmbilAntrian()
        }

        // 4. Tombol Asisten Tunawicara
        binding.btnSpeakTunawicara.setOnClickListener {
            val text = binding.etTunawicaraInput.text.toString().trim()
            if (text.isNotEmpty()) {
                Toast.makeText(context, "Menyuarakan: \"$text\"", Toast.LENGTH_SHORT).show()
                ttsManager.speak(text)
                binding.etTunawicaraInput.text?.clear()
            } else {
                Toast.makeText(context, "Ketik teks terlebih dahulu", Toast.LENGTH_SHORT).show()
            }
        }

        // 5. Aksi Klik pada Area Mic / Teks agar mulai mendengarkan suara
        val startListeningAction = View.OnClickListener {
            startListeningVoice()
        }
        binding.headerArea.setOnClickListener(startListeningAction)
        binding.tvVoiceHint.setOnClickListener(startListeningAction)
    }

    private fun checkMicrophonePermission() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
        }
    }

    private fun setupSpeechToText() {
        if (SpeechRecognizer.isRecognitionAvailable(requireContext())) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(requireContext())
            speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale("id", "ID")) // Set Bahasa Indonesia
            }

            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    binding.tvVoiceHint.text = "Mendengarkan..."
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    binding.tvVoiceHint.text = "Memproses suara..."
                }

                override fun onError(error: Int) {
                    binding.tvVoiceHint.text = "Ketuk untuk Bicara"
                    Toast.makeText(context, "Gagal mengenali suara, coba lagi.", Toast.LENGTH_SHORT).show()
                }

                override fun onResults(results: Bundle?) {
                    binding.tvVoiceHint.text = "Ucapkan 'Ambil Antrian'"
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val voiceText = matches[0].lowercase(Locale.ROOT)

                        // Logika pendeteksi kata kunci suara
                        if (voiceText.contains("ambil antrian") || voiceText.contains("antrian")) {
                            triggerAmbilAntrian()
                        } else {
                            Toast.makeText(context, "Kata kunci salah: \"$voiceText\"", Toast.LENGTH_LONG).show()
                        }
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun startListeningVoice() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED) {
            speechRecognizer?.startListening(speechIntent)
        } else {
            checkMicrophonePermission()
        }
    }

    // UPDATE: Menggunakan Simulasi Lokal SharedPreferences (Anti Ribet & Anti Mager)
    private fun triggerAmbilAntrian() {
        // 1. Ambil shared preference penyimpanan lokal HP
        val sharedPref = requireActivity().getSharedPreferences("QueueEasyPref", Context.MODE_PRIVATE)

        // 2. Ambil nilai counter saat ini (default 0 jika belum ada data)
        val currentCounter = sharedPref.getInt("local_counter", 0)

        // 3. Tambah angka antrian berikutnya
        val nextCounter = currentCounter + 1

        // 4. Simpan kembali angka terbaru ke memori internal HP
        sharedPref.edit().putInt("local_counter", nextCounter).apply()

        // 5. Format teks menjadi 3 digit angka (Contoh: A001, A002, dst.)
        val nomorFormatted = String.format("A%03d", nextCounter)

        // 6. Simpan string tiket agar bisa dibaca oleh TicketFragment secara sinkron
        sharedPref.edit().putString("my_ticket", nomorFormatted).apply()

        // 7. Tampilkan pop-up informasi dan bunyikan suara asisten
        val pesanKelepon = "Antrian berhasil diambil. Nomor Anda adalah $nomorFormatted. Mohon tunggu dipanggil."
        Toast.makeText(context, pesanKelepon, Toast.LENGTH_LONG).show()
        ttsManager.speak(pesanKelepon)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        speechRecognizer?.destroy()
        ttsManager.shutdown()
        _binding = null
    }
}