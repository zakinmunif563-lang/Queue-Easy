package com.zakin.queueeasy.ui

import android.os.Bundle
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.zakin.queueeasy.databinding.ActivityQueueBinding
import com.zakin.queueeasy.model.Ticket
import com.zakin.queueeasy.utils.FlashlightManager
import com.zakin.queueeasy.utils.TtsManager
import com.zakin.queueeasy.utils.VibrationPattern

class QueueActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQueueBinding
    private lateinit var ttsManager: TtsManager
    private lateinit var vibratorPattern: VibrationPattern
    private lateinit var flashlightManager: FlashlightManager
    private val databaseRef = FirebaseDatabase.getInstance().getReference("QueueEasy")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQueueBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ttsManager = TtsManager(this)
        vibratorPattern = VibrationPattern(this)
        flashlightManager = FlashlightManager(this)

        val ticketId = intent.getStringExtra("TICKET_ID") ?: ""
        listenToTicketUpdates(ticketId)

        binding.btnPanic.setOnClickListener {
            databaseRef.child("panic_alerts").child(ticketId).setValue(true)
        }
    }

    private fun listenToTicketUpdates(ticketId: String) {
        databaseRef.child("tickets").child(ticketId)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val ticket = snapshot.getValue(Ticket::class.java) ?: return

                    if (ticket.status == "called") {
                        ttsManager.speak("Nomor antrian ${ticket.nomor}, silakan menuju ke loket ${ticket.loket}")
                        vibratorPattern.vibrateGiliranTiba()
                        flashlightManager.flashAlert()

                        val pulseAnim = AnimationUtils.loadAnimation(this@QueueActivity, android.R.anim.fade_in)
                        binding.tvNomorAntrian.startAnimation(pulseAnim)
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown()
    }
}