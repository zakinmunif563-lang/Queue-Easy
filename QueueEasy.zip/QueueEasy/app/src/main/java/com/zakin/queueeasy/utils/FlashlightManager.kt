package com.zakin.queueeasy.utils

import android.content.Context
import android.hardware.camera2.CameraManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class FlashlightManager(private val context: Context) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var cameraId: String? = null

    init {
        try {
            cameraId = cameraManager.cameraIdList[0]
        } catch (_: Exception) {}
    }

    fun flashAlert() {
        cameraId?.let { id ->
            CoroutineScope(Dispatchers.Default).launch {
                for (i in 1..5) {
                    try {
                        cameraManager.setTorchMode(id, true)
                        delay(200)
                        cameraManager.setTorchMode(id, false)
                        delay(200)
                    } catch (_: Exception) {}
                }
            }
        }
    }
}