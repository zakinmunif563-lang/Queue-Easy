package com.zakin.queueeasy.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.zakin.queueeasy.databinding.FragmentMonitorBinding

class MonitorFragment : Fragment() {

    private var _binding: FragmentMonitorBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMonitorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Simulasi update data awal (Nanti diconnect ke database Firebase milikmu)
        binding.tvLiveQueueNumber.text = "A011"
        binding.tvCurrentCounter.text = "Sedang Dipanggil di Loket 2"
        binding.tvEstimatedDetail.text = "Sekitar 3 antrian lagi (~12 menit)"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}