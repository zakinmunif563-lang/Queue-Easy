package com.zakin.queueeasy.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.zakin.queueeasy.R
import com.zakin.queueeasy.databinding.ActivityMainBinding
import com.zakin.queueeasy.ui.fragment.HomeFragment
import com.zakin.queueeasy.ui.fragment.MonitorFragment
import com.zakin.queueeasy.ui.fragment.SettingFragment
import com.zakin.queueeasy.ui.fragment.TicketFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set fragment pertama kali muncul (Beranda/HomeFragment)
        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
        }

        // Logika perpindahan halaman saat Bottom Nav diclick
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            val fragment: Fragment = when (item.itemId) {
                R.id.nav_home -> HomeFragment()
                R.id.nav_monitor -> MonitorFragment()
                R.id.nav_ticket -> TicketFragment()
                R.id.nav_setting -> SettingFragment()
                else -> HomeFragment()
            }
            loadFragment(fragment)
        }
    }

    // Fungsi helper untuk menempelkan fragment ke FrameLayout
    private fun loadFragment(fragment: Fragment): Boolean {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
        return true
    }
}