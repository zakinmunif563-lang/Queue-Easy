package com.zakin.queueeasy.ui.fragment

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.zakin.queueeasy.databinding.FragmentTicketBinding

class TicketFragment : Fragment() {

    private var _binding: FragmentTicketBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTicketBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 1. Ambil nomor tiket dinamis yang tadi disimpan oleh HomeFragment di memori lokal HP
        val sharedPref = requireActivity().getSharedPreferences("QueueEasyPref", Context.MODE_PRIVATE)
        val myTicket = sharedPref.getString("my_ticket", "Belum Ada")

        // 2. Tampilkan nomor ke komponen UI TextView kamu
        binding.tvMyQueueNumber.text = myTicket

        // 3. Logika penyesuaian teks status berdasarkan ada atau tidaknya tiket aktif
        if (myTicket == "Belum Ada") {
            binding.tvTicketStatus.text = "Status: Tidak Ada Antrian"
            binding.tvTicketDetail.text = "Silakan ambil nomor antrian di halaman Beranda terlebih dahulu."
        } else {
            binding.tvTicketStatus.text = "Status: Menunggu Giliran"
            binding.tvTicketDetail.text = "Silakan tunggu di area ruang utama instansi."
        }

        // 4. Tombol darurat/bantuan darurat
        binding.btnPanic.setOnClickListener {
            Toast.makeText(context, "Sinyal bantuan dikirim! Petugas segera ke lokasi Anda.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}