package com.zakin.queueeasy.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ScanQrActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Nanti layout XML scanner dimasukkan di sini
    }
}