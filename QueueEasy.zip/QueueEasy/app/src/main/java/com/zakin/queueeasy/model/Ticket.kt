package com.zakin.queueeasy.model

// Menggunakan 'data class' khas Kotlin, otomatis menghandle getter & setter
data class Ticket(
    val ticketId: String = "",
    val nomor: String = "",
    val userId: String = "",
    val lokasiId: String = "",
    val loket: String = "Menunggu",
    val status: String = "waiting", // waiting, called, done
    val jenisDisabilitas: String = "",
    val timestamp: Long = System.currentTimeMillis()
)